from __future__ import absolute_import, division, print_function
import tensorflow as tf
tf.enable_eager_execution()
import matplotlib.pyplot as plt
import numpy as np
import time
import dill
import json
import copy

import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'


#################################################################################
def gradtovec(grad):
    vec=np.array([])
    le=len(grad)
    for i in range(0,le):
        a=grad[i]
        b = a.numpy()

        if len(a.shape)==2:
            da = int(a.shape[0])
            db = int(a.shape[1])
            b=b.reshape(da*db)
       # else:
        #    da = int(a.shape[0])
        #    b.reshape(da)
        vec=np.concatenate((vec,b),axis=0)
    return vec

def vectograd(vec,grad):
    le=len(grad)
    for i in range(0,le):
        a=grad[i]
        #b=a.numpy()
        if len(a.shape)==2:
            da=int(a.shape[0])
            db=int(a.shape[1])
            c=vec[0:da*db]
            c=c.reshape(da,db)
            lev=len(vec)
            vec=vec[da*db:lev]
        else:
            da=int(a.shape[0])
            c=vec[0:da]
            lev = len(vec)
            vec = vec[da:lev]
        grad[i]=0*grad[i]+c
    return grad

def quantr(vec,s):
    norv=vec.dot(vec)
    norv=norv**(0.5)
    norv=1
    norvec=vec/norv
    le=len(vec)
    q=np.zeros(le)
    for i in range(0,le):
        k=0
        while(norvec[i]>k/s):
            k=k+1
        rr=np.random.uniform(0,1)
        if (rr>norvec[i]-k/s):
            q[i]=k
        else:
            q[i]=k+1
    quantv=q/s*norv
    return quantv

def quantd(vec,v2,b):
    n=len(vec)
    r=max(abs(vec-v2))
    delta=r/(np.floor(2**b)-1)
    quantv=v2-r+2*delta*np.floor((vec-v2+r+delta)/(2*delta))
    return quantv

def quants(vec, p):
    le=len(vec)
    quantv=np.zeros(vec.shape)
    for i in range(0,le):
        rr = np.random.uniform(0, 1)
        if rr<=p:
            quantv[i]=vec[i]/p

    return quantv






#########################################################################
#alg=0:QLAG;alg=1:GD; alg=2:rQGD;alg=3:sGD

tic=time.time()
#alg=0 #cl=0.05;alpha=0.02;Iter=5000

nalg=5;Iter=5000;Iter=8000;C=100;ck=0.8;Iter=4000;Iter=8000;
Loss=np.zeros((nalg,Iter))
Cr=np.zeros((nalg,Iter))
Gradnorm=np.zeros((nalg,Iter))
Acc=np.zeros(nalg)
beta=0.001;

for al in range(0,nalg):

    alg=al
    b=8;s=10;p=0.5
    alpha=0.02;alpah=0.02
    #alpha=ck*alpha
    cl=0.01;
    M=10;D=10
    (mnist_images, mnist_labels), (mnist_ta,mnist_tb)= tf.keras.datasets.mnist.load_data()
    mnist_ta=mnist_ta/255
    Ntr=mnist_images.__len__()
    Nte=mnist_ta.__len__()
    Mi=int(Ntr/M)
    Datatr=M*[0];
    for m in range(0,M):
        datr=tf.data.Dataset.from_tensor_slices(
            (tf.cast(mnist_images[m*Mi:(m+1)*Mi,tf.newaxis]/255, tf.float32),
            tf.cast(mnist_labels[m*Mi:(m+1)*Mi],tf.int64)))
        datr=datr.batch(Mi)
        Datatr[m]=datr



    Datate = tf.data.Dataset.from_tensor_slices(
      (tf.cast(mnist_ta[...,tf.newaxis], tf.float32),
       tf.cast(mnist_tb,tf.int64)))
    Datate=Datate.batch(1)

    nl=len(mnist_tb)
    mnistl=np.eye(10)[mnist_tb]

    # Build the model

    '''
    mnist_model = tf.keras.models.Sequential([
      tf.keras.layers.Conv2D(16,[3,3], activation='relu'),
      tf.keras.layers.Conv2D(16,[3,3], activation='relu'),
      tf.keras.layers.GlobalAveragePooling2D(),
      tf.keras.layers.Dense(10)
    ])
    '''
    regularizer = tf.contrib.layers.l2_regularizer(scale=0.9)
    tf.random.set_random_seed(1234)
    mnist_model = tf.keras.models.Sequential([
      tf.keras.layers.Flatten(input_shape=(28, 28)),
      #tf.keras.layers.Dense(512, activation=tf.nn.relu),
      #tf.keras.layers.Dropout(0.2),
    #tf.keras.layers.Dense(120, activation=tf.nn.relu,kernel_regularizer=regularizer),
     tf.keras.layers.Dense(200, activation=tf.nn.relu),
      #tf.keras.layers.Dense(10, kernel_regularizer=regularizer)
      tf.keras.layers.Dense(10)
    ])
    mnist_model.compile(optimizer=tf.train.GradientDescentOptimizer(alpha),
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])





    #mnist_model.compile(metrics='accuracy')

    for images,labels in Datatr[1].take(1):
      print("Logits: ", mnist_model(images[0:1]).numpy())

    #optimizer = tf.train.AdamOptimizer()
    optimizer=tf.train.GradientDescentOptimizer(alpha)



    le=len(mnist_model.trainable_variables)
    nv=0
    for i in range (0,le):
        a =mnist_model.trainable_variables[i]
        if (len(a.shape)==2):
            da=int(a.shape[0])
            db=int(a.shape[1])
            nv=nv+da*db
        if (len(a.shape)==1):
            da=int(a.shape[0])
            nv=nv+da

    clock=np.zeros(M)
    e=np.zeros(M)
    ehat=np.zeros(M)
    theta=np.zeros(nv)
    thetat=np.zeros(nv)
    dtheta=np.zeros((nv,Iter))
    #mtheta=np.zeros((M,nv,Iter))
    gr=np.zeros((M,nv))
    mgr=np.zeros((M,nv))
    dL=np.zeros((M,nv))

    dsa=np.zeros(nv)
    gm=np.zeros((M,nv))
    D=10;ksi=np.ones((D,D+1));#ksi=np.matrix(ksi);
    for i in range(0,D+1):
        if (i==0):
            ksi[:,i]=np.ones(D);
        if (i<=D and i>0):
            ksi[:, i] = 1/i*np.ones(D);
    ksi=ck*ksi
    #ksi=0.002*ksi

    if (alg==0 or alg==3 or alg==4):
        Ind=np.zeros((M,Iter))
    if (alg==1 or alg==2):
        Ind=np.ones((M,Iter))


    loss_history = np.zeros(Iter)
    lossfg=np.zeros(Iter)
    lossfr=np.zeros(Iter)
    lossfr2=np.zeros(Iter)
    grnorm=np.zeros(Iter)

    thetatw = gradtovec(mnist_model.trainable_variables)

    for k in range(0,Iter):
        if k==0:
            thetat=gradtovec(mnist_model.trainable_variables)
        if k>=1:
            thetat=var
        me=np.zeros(M)
        var=gradtovec(mnist_model.trainable_variables)
        if (k>=1):
            dtheta[:,k]=var-theta
        theta = var

        for m in range(0,M):
            for (batch, (images,labels)) in enumerate(Datatr[m].take(1)):
                with tf.GradientTape() as tape:
                    logits=mnist_model(images, training=True)
                    loss_value = tf.losses.sparse_softmax_cross_entropy(labels, logits)
                    for i in range(0,len(mnist_model.trainable_variables)):
                        if i==0:
                            l2_loss=cl*tf.nn.l2_loss(mnist_model.trainable_variables[i])
                        if i>=1:
                            l2_loss=l2_loss+cl*tf.nn.l2_loss(mnist_model.trainable_variables[i])

                    #l2_loss = tf.losses.get_regularization_loss()
                    loss_value=loss_value+l2_loss
                grads=tape.gradient(loss_value, mnist_model.trainable_variables)
                vec=gradtovec(grads)
                bvec=vec
                if (alg==0 or alg==2 or alg==4):
                    vec=quantd(vec,mgr[m,:],b)
                gr[m,:]=vec
                dvec=vec-bvec
                e[m]=(dvec.dot(dvec))

            for d in range(0,D):
                if (k-d>=0):
                    if (k<=D):
                        me[m]=me[m]+ksi[d,k]*dtheta[:,k-d].dot(dtheta[:,k-d])
                    if (k>D):
                        me[m]=me[m]+ksi[d,D]*dtheta[:,k-d].dot(dtheta[:,k-d])
            dL[m,:]=gr[m,:]-mgr[m,:]
            if ((dL[m,:].dot(dL[m,:]))>=(1/(alpha**2*M**2))*me[m]+3*(e[m]+ehat[m]) or clock[m]==C):
                Ind[m,k]=1

            if (Ind[m,k]==1):
                mgr[m,:]=gr[m,:]
                ehat[m]=e[m]
                clock[m]=0
                dsa=dsa+dL[m,:]
            if (Ind[m, k] == 0):
                clock[m]=clock[m]+1

            if m==0:
                g=grads
                loss=loss_value.numpy()/M
            else:
                g=[a+b for a,b in zip(g,grads)]
                loss=loss+loss_value.numpy()/M
        lossfr2[k]=l2_loss
        #lossfg[k]=loss
        lossfr[k] = 0
        for i in range(0, len(mnist_model.trainable_variables)):
            #loss= loss+ cl * np.linalg.norm(mnist_model.trainable_variables[i].numpy()) ** 2
            lossfr[k]=lossfr[k]+cl * np.linalg.norm(mnist_model.trainable_variables[i].numpy()) ** 2
        loss_history[k]=loss

        #dsa=dsa-beta/alpha*(theta-thetat)
        ccgrads=vectograd(dsa, grads)
        #grr = copy.deepcopy(mnist_model.trainable_variables)
        #grr2 = [c * cl * 2 for c in grr]
        #ccgrads = [a + b for a, b in zip(cgrads, grr2)]
        #ccgrads=cgrads
        for i in range(0,len(ccgrads)):
            grnorm[k]=grnorm[k]+tf.nn.l2_loss(ccgrads[i]).numpy()
        optimizer.apply_gradients(zip(ccgrads, mnist_model.trainable_variables),
                                  global_step=tf.train.get_or_create_global_step())



        if (alg == 4):
            thetatw = theta
            th = gradtovec(mnist_model.trainable_variables)
            th = quantd(th,thetatw, b)
            wei = mnist_model.get_weights()
            thetalist = vectograd(th, wei)
            mnist_model.set_weights(thetalist)


    acc=mnist_model.evaluate(mnist_ta,mnistl)
    Acc[alg]=acc[1]
    lossfrv=loss_history-lossfg
    plt.plot(loss_history)
    plt.xlabel('Iterations#')
    plt.ylabel('Loss [entropy]');
    plt.show()

    deloss=np.array(loss_history)
    ll=len(deloss)
    lossopt=deloss[ll-1]
    deloss=deloss-lossopt
    plt.figure; plt.plot(deloss)
    plt.xlabel('Batch #')
    plt.ylabel('Loss [entropy]')
    plt.yscale('log')
    plt.show()

    plt.plot(Acc)
    plt.xlabel('Batch #')
    plt.ylabel('Accuracy')
    plt.show()

    '''
    s = 0;acc = 0
    for ba, (ta, tb) in enumerate(Datate.take(10000)):
      logit = mnist_model(ta[0:1]).numpy()
      dig = logit.argmax()
      if (dig == tb.numpy()[0]):
          acc = acc + 1
      s = s + 1
    acc=acc/s

    datatesta = tf.data.Dataset.from_tensor_slices(
      tf.cast(mnist_ta[...,tf.newaxis]/255, tf.float32))

    datatestb = tf.data.Dataset.from_tensor_slices(
       tf.cast(mnist_tb,tf.int64))
     '''

    plt.figure();plt.stem(Ind[0,:].T);plt.show();
    plt.figure();plt.stem(Ind[5,:].T);plt.show();
    plt.figure();plt.stem(Ind[9,:].T);plt.show();


    Inds = sum(Ind)
    commrou = np.zeros(Iter)
    for i in range(0, Iter):
        if i == 0:
            commrou[i] = Inds[i]
        if i >= 1:
            commrou[i] = commrou[i - 1] + Inds[i]
    Loss[alg] = loss_history
    Cr[alg] = commrou
    Gradnorm[alg]=grnorm
    '''
        if alg==0:
            dill.dump_session('QLAG1.pkl')
        if alg==1:
            dill.dump_session('GD1.pkl')
        if alg==2:
            dill.dump_session('QGD1.pkl')
        if alg==3:
            dill.dump_session('LAG1.pkl')
    '''


toc=time.time()
runtime=toc-tic

plt.figure();plt.plot(Cr[0],Loss[0],'r',lw=3,label='QLAG');plt.plot(Cr[1],Loss[1],'b',lw=2,linestyle=':',label='GD');
plt.plot(Cr[2],Loss[2],'g',lw=3,label='QGD');plt.plot(Cr[3],Loss[3],'m',lw=2,linestyle=':',label='LAG');plt.yscale('log')
plt.xlabel('Number of communications(uploads)');plt.ylabel('Loss function');
plt.legend();plt.show();




reloss=Iter*[0]
for i in range(0,Iter):
    reloss[i]=loss_history[i]
reloss
'''
with open('loss6000.txt','w') as f:
    json.dump(reloss, f)
with open('loss6000.txt','r') as f:
    loss6=json.load(f)
'''
LossGradrou=np.concatenate((Loss,Gradnorm,Cr),axis=0)
if b==8:
    np.savetxt('eLossGradrouAllQpltb8a2ck.txt',LossGradrou)
    LossGradrou=np.loadtxt('eLossGradrouAllQpltb8a2ck.txt')
if b==4:
    np.savetxt('eLossGradrouAllQpltb4ck.txt', LossGradrou)
    LossGradrou = np.loadtxt('eLossGradrouAllQpltb4ck.txt')

float=32;
down=np.array(range(1,Iter+1));
Bit=np.zeros((nalg,Iter))
Bit[0]=b*nv*(Cr[0])+float*nv*down;Bit[1]=float*nv* (Cr[1]+down)
Bit[2]=b*nv*Cr[2]+float*nv*down;Bit[3]=float*nv*(Cr[3]+down);
Bit[4]=b*nv*(Cr[4]+down);

'''
Loss=LossGradrou[0:nalg,:]
Gradnorm=LossGradrou[nalg:2*nalg,:]
Cr=LossGradrou[2*nalg:3*nalg,:]
'''

minl=Loss.min()
float=32
deLoss=Loss-minl


index=np.zeros(nalg)
for i in range(0,nalg):
    k=0
    while(deLoss[i,k]>10**(-6) and k<Iter-1):
        k=k+1
    index[i]=k

[Cr[0,int(index[0])], Cr[1,int(index[1])],Cr[2,int(index[2])],Cr[3,int(index[3])]] #communication #
[b*nv*Cr[0,int(index[0])],float*nv* Cr[1,int(index[1])],b*nv*Cr[2,int(index[2])],float*nv*Cr[3,int(index[3])]]


plt.figure();plt.plot(deLoss[0],'r',lw=3,label='LAQ');plt.plot(deLoss[1],'b',lw=2,linestyle=':',label='GD');
plt.plot(deLoss[2],'g',lw=3,label='QGD');plt.plot(deLoss[3],'m',lw=2,linestyle=':',label='LAG');plt.yscale('log');plt.xscale('log')
plt.xlabel('Number of iterations');plt.ylabel('Loss function');
plt.legend();plt.show();

plt.figure();plt.plot(Cr[0],deLoss[0],'r',lw=3,label='LAQ');plt.plot(Cr[1],deLoss[1],'b',lw=2,linestyle=':',label='SGD');
plt.plot(Cr[2],deLoss[2],'g',lw=3,label='QGD');plt.plot(Cr[3],deLoss[3],'m',lw=2,linestyle=':',label='LAG');plt.yscale('log');plt.xscale('log')
plt.xlabel('Number of communications(uploads)');plt.ylabel('Loss function');
plt.legend();plt.show();

plt.figure();plt.plot(b*Cr[0],deLoss[0],'r',lw=2.5,label='LAQ');plt.plot(float*Cr[1],deLoss[1],'b',lw=2,linestyle=':',label='GD');
plt.plot(b*Cr[2],deLoss[2],'g',lw=2.5,label='QGD');plt.plot(float*Cr[3],deLoss[3],'m',lw=2.5,linestyle=':',label='LAG');plt.yscale('log');plt.xscale('log')
plt.xlabel('Number of bits');plt.ylabel('Loss function');
plt.legend();plt.show();





plt.figure();plt.plot(deLoss[0],'r',lw=2.5,label='LAQ');plt.plot(deLoss[4],'g',lw=2.5,linestyle='--',label='TWICE');
plt.plot(deLoss[1],'b',lw=3.5,label='GD');
plt.plot(deLoss[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(deLoss[3],'m',lw=2.5,label='LAG');plt.yscale('log');
plt.xlabel(r'Number of iterations',fontsize=17);plt.ylabel('Loss residual~'+r'$(f-f^*)$',fontsize=17);
plt.grid(True, which="both",ls=':')
plt.legend(fontsize=16);plt.ylim(10**(-6),10**1);plt.xlim(-100,3000);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/lossiter.eps');plt.savefig('figures2/lossiter.pdf');
plt.show();



plt.figure();plt.plot(Cr[0],deLoss[0],'r',lw=2.5,label='LAQ');plt.plot(Cr[4],deLoss[4],'g',lw=2.5,linestyle='--',label='TWICE');
plt.plot(Cr[1],deLoss[1],'b',lw=3.5,label='GD');
plt.plot(Cr[2],deLoss[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(Cr[3],deLoss[3],'m',lw=2.5,label='LAG');plt.yscale('log');plt.xscale('log')
plt.xlabel(r'Number of communications',fontsize=17);plt.ylabel('Loss residual~'+r'$(f-f^*)$',fontsize=17);
plt.grid(True, which='both',ls=':')
plt.legend(fontsize=16);plt.ylim(10**(-6),10**1);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/losscom.eps');plt.savefig('figures2/losscom.pdf')
plt.show();



X1=np.zeros(Iter+1);X1[0]=b*nv*Cr[0,1];X1[1:Iter+1]=float*nv*Cr[1];
Y1=np.zeros(Iter+1);Y1[0]=deLoss[1,0];Y1[1:Iter+1]=deLoss[1];

X3=np.zeros(Iter+1);X3[0]=b*nv*Cr[0,1];X3[1:Iter+1]=float*nv*Cr[3];
Y3=np.zeros(Iter+1);Y3[0]=deLoss[1,0];Y3[1:Iter+1]=deLoss[3];

plt.figure();fig,ax=plt.subplots();plt.rc('text', usetex=True)
plt.plot(b*nv*Cr[0],deLoss[0],'r',lw=2.5,label='LAQ');
plt.plot(X1,Y1,'b',lw=3.5,label='GD');
plt.plot(b*nv*Cr[2],deLoss[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(X3,Y3,'m',lw=2.5,label='LAG');plt.yscale('log');plt.xscale('log')
plt.grid(True, which='both',ls=':')
plt.xlabel(r'Number of bits',fontsize=17);plt.ylabel('Loss residual~'+r'$(f-f^*)$',fontsize=17);
plt.legend(fontsize=16);plt.ylim(10**(-6),10**1);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
#ax.set(ylabel=r'$\mathcal{L}-\mathcal{L}^*$') #||\nabla\mathcal{L}(\theta^k)||
#ax.yaxis.label.set_size(15)
plt.savefig('figures2/lossbit.eps');plt.savefig('figures2/lossbit.pdf')
plt.show();


'''
plt.figure();fig,ax=plt.subplots();plt.rc('text', usetex=True)
plt.plot(b*nv*Cr[0],deLoss[0],'r',lw=2.5,label='QCGD');plt.plot(float*nv*Cr[1],deLoss[1],'b',lw=3.5,label='GD');
plt.plot(b*nv*Cr[2],deLoss[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(float*nv*Cr[3],deLoss[3],'m',lw=2.5,label='LAG');plt.yscale('log');plt.xscale('log')
plt.grid(True, which='both',ls=':')
plt.xlabel(r'Number of bits',fontsize=17);plt.ylabel(r'$f-f^*$',fontsize=13.5);
plt.legend(fontsize=16);plt.ylim(10**(-6),10**1);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
#ax.set(ylabel=r'$\mathcal{L}-\mathcal{L}^*$') #||\nabla\mathcal{L}(\theta^k)||
#ax.yaxis.label.set_size(15)
plt.savefig('figures2/lossbit.eps');plt.savefig('figures2/lossbit.pdf')
plt.show();
'''

plt.figure();fig,ax=plt.subplots();plt.plot(Gradnorm[0],'r',lw=2.5,label='LAQ');plt.plot(Gradnorm[1],'b',lw=3.5,label='GD');
plt.plot(Gradnorm[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(Gradnorm[3],'m',lw=2.5,label='LAG');plt.yscale('log');#plt.xscale('log');
plt.grid(True, which='both',ls=':')
plt.xlabel('Number of iterations',fontsize=16);plt.ylabel('Gradient norm~'+r'$||\nabla f||$',fontsize=17);
plt.legend(fontsize=16);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/normiter.eps');plt.savefig('figures2/normiter.pdf')
plt.show();

plt.figure();fig,ax=plt.subplots();plt.plot(Cr[0],Gradnorm[0],'r',lw=2.5,label='LAQ');plt.plot(Cr[1],Gradnorm[1],'b',lw=3.5,label='GD');
plt.plot(Cr[2],Gradnorm[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(Cr[3],Gradnorm[3],'m',lw=2.5,label='LAG');plt.yscale('log');#plt.xscale('log');
plt.grid(True, which='both',ls=':')
plt.xlabel('Number of communications',fontsize=16);plt.ylabel('Gradient norm~'+r'$||\nabla f||$',fontsize=17);
plt.legend(fontsize=16);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/normcom.eps');plt.savefig('figures2/normcom.pdf')
plt.show();

plt.figure();fig,ax=plt.subplots();plt.plot(b*nv*Cr[0],Gradnorm[0],'r',lw=2.5,label='LAQ');plt.plot(float*nv*Cr[1],Gradnorm[1],'b',lw=3.5,label='GD');
plt.plot(b*nv*Cr[2],Gradnorm[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(float*nv*Cr[3],Gradnorm[3],'m',lw=2.5,label='LAG');plt.yscale('log');#plt.xscale('log');
plt.grid(True, which='both',ls=':')
plt.xlabel('Number of bits',fontsize=16);plt.ylabel('Gradient norm~'+r'$||\nabla f||$',fontsize=17);
plt.legend(fontsize=16);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/normbit.eps');plt.savefig('figures2/normbit.pdf')
plt.show();

plt.figure();fig,ax=plt.subplots();plt.rc('text', usetex=True)
plt.plot(b*nv*Cr[0],deLoss[0],'r',lw=2.5,label='LAQ');plt.plot(float*nv*Cr[1],deLoss[1],'b',lw=2.5,label='GD');
plt.plot(b*nv*Cr[2],deLoss[2],'g',lw=2.5,label='QGD');plt.plot(float*nv*Cr[3],deLoss[3],'m',lw=2.5,label='LAG');plt.yscale('log');plt.xscale('log')
plt.grid(True, which='both',ls=':')
plt.xlabel(r'Number of bits',fontsize=17);plt.ylabel('Loss residual~'+r'$(f-f^*)$',fontsize=17);
plt.legend(fontsize=15);plt.ylim(10**(-6),10**1);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=18)
#ax.set(ylabel=r'$\mathcal{L}-\mathcal{L}^*$') #||\nabla\mathcal{L}(\theta^k)||
#ax.yaxis.label.set_size(15)
plt.savefig('figures/lossbit.eps');plt.savefig('figures/lossbit.pdf')
plt.show();


'''
plt.figure();plt.plot(deLoss[0],'r',lw=2.5,label='QCGD');plt.plot(deLoss[1],'b',lw=3.5,label='GD');
plt.plot(deLoss[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(deLoss[3],'m',lw=2.5,label='LAG');plt.yscale('log');
plt.xlabel(r'Number of iterations',fontsize=17);plt.ylabel(r'$f-f^*$',fontsize=13.5);
plt.grid(True, which="both",ls=':')
plt.legend(fontsize=16);plt.ylim(10**(-6),10**1);plt.xlim(-100,3000);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/lossiter.eps');plt.savefig('figures2/lossiter.pdf');
plt.show();



plt.figure();plt.plot(Cr[0],deLoss[0],'r',lw=2.5,label='QCGD');plt.plot(Cr[1],deLoss[1],'b',lw=3.5,label='GD');
plt.plot(Cr[2],deLoss[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(Cr[3],deLoss[3],'m',lw=2.5,label='LAG');plt.yscale('log');plt.xscale('log')
plt.xlabel(r'Number of communications',fontsize=17);plt.ylabel(r'$f-f^*$',fontsize=13.5);
plt.grid(True, which='both',ls=':')
plt.legend(fontsize=16);plt.ylim(10**(-6),10**1);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/losscom.eps');plt.savefig('figures2/losscom.pdf')
plt.show();



X1=np.zeros(Iter+1);X1[0]=b*nv*Cr[0,1];X1[1:Iter+1]=float*nv*Cr[1];
Y1=np.zeros(Iter+1);Y1[0]=deLoss[1,0];Y1[1:Iter+1]=deLoss[1];

X3=np.zeros(Iter+1);X3[0]=b*nv*Cr[0,1];X3[1:Iter+1]=float*nv*Cr[3];
Y3=np.zeros(Iter+1);Y3[0]=deLoss[1,0];Y3[1:Iter+1]=deLoss[3];

plt.figure();fig,ax=plt.subplots();plt.rc('text', usetex=True)
plt.plot(b*nv*Cr[0],deLoss[0],'r',lw=2.5,label='QCGD');plt.plot(X1,Y1,'b',lw=3.5,label='GD');
plt.plot(b*nv*Cr[2],deLoss[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(X3,Y3,'m',lw=2.5,label='LAG');plt.yscale('log');plt.xscale('log')
plt.grid(True, which='both',ls=':')
plt.xlabel(r'Number of bits',fontsize=17);plt.ylabel(r'$f-f^*$',fontsize=13.5);
plt.legend(fontsize=16);plt.ylim(10**(-6),10**1);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
#ax.set(ylabel=r'$\mathcal{L}-\mathcal{L}^*$') #||\nabla\mathcal{L}(\theta^k)||
#ax.yaxis.label.set_size(15)
plt.savefig('figures2/lossbit.eps');plt.savefig('figures2/lossbit.pdf')
plt.show();



plt.figure();fig,ax=plt.subplots();plt.rc('text', usetex=True)
plt.plot(b*nv*Cr[0],deLoss[0],'r',lw=2.5,label='QCGD');plt.plot(float*nv*Cr[1],deLoss[1],'b',lw=3.5,label='GD');
plt.plot(b*nv*Cr[2],deLoss[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(float*nv*Cr[3],deLoss[3],'m',lw=2.5,label='LAG');plt.yscale('log');plt.xscale('log')
plt.grid(True, which='both',ls=':')
plt.xlabel(r'Number of bits',fontsize=17);plt.ylabel(r'$f-f^*$',fontsize=13.5);
plt.legend(fontsize=16);plt.ylim(10**(-6),10**1);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
#ax.set(ylabel=r'$\mathcal{L}-\mathcal{L}^*$') #||\nabla\mathcal{L}(\theta^k)||
#ax.yaxis.label.set_size(15)
plt.savefig('figures2/lossbit.eps');plt.savefig('figures2/lossbit.pdf')
plt.show();

plt.figure();fig,ax=plt.subplots();plt.plot(Gradnorm[0],'r',lw=2.5,label='QCGD');plt.plot(Gradnorm[1],'b',lw=3.5,label='GD');
plt.plot(Gradnorm[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(Gradnorm[3],'m',lw=2.5,label='LAG');plt.yscale('log');#plt.xscale('log');
plt.grid(True, which='both',ls=':')
plt.xlabel('Number of iterations',fontsize=16);plt.ylabel(r'$||\nabla f||$',fontsize=13.5);
plt.legend(fontsize=16);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/normiter.eps');plt.savefig('figures2/normiter.pdf')
plt.show();

plt.figure();fig,ax=plt.subplots();plt.plot(Cr[0],Gradnorm[0],'r',lw=2.5,label='QCGD');plt.plot(Cr[1],Gradnorm[1],'b',lw=3.5,label='GD');
plt.plot(Cr[2],Gradnorm[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(Cr[3],Gradnorm[3],'m',lw=2.5,label='LAG');plt.yscale('log');#plt.xscale('log');
plt.grid(True, which='both',ls=':')
plt.xlabel('Number of communications',fontsize=16);plt.ylabel(r'$||\nabla f||$',fontsize=13.5);
plt.legend(fontsize=16);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/normcom.eps');plt.savefig('figures2/normcom.pdf')
plt.show();

plt.figure();fig,ax=plt.subplots();plt.plot(b*nv*Cr[0],Gradnorm[0],'r',lw=2.5,label='QCGD');plt.plot(float*nv*Cr[1],Gradnorm[1],'b',lw=3.5,label='GD');
plt.plot(b*nv*Cr[2],Gradnorm[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(float*nv*Cr[3],Gradnorm[3],'m',lw=2.5,label='LAG');plt.yscale('log');#plt.xscale('log');
plt.grid(True, which='both',ls=':')
plt.xlabel('Number of bits',fontsize=16);plt.ylabel(r'$||\nabla f||$',fontsize=13.5);
plt.legend(fontsize=16);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/normbit.eps');plt.savefig('figures2/normbit.pdf')
plt.show();

plt.figure();fig,ax=plt.subplots();plt.rc('text', usetex=True)
plt.plot(b*nv*Cr[0],deLoss[0],'r',lw=2.5,label='QCGD');plt.plot(float*nv*Cr[1],deLoss[1],'b',lw=2.5,label='GD');
plt.plot(b*nv*Cr[2],deLoss[2],'g',lw=2.5,label='QGD');plt.plot(float*nv*Cr[3],deLoss[3],'m',lw=2.5,label='LAG');plt.yscale('log');plt.xscale('log')
plt.grid(True, which='both',ls=':')
plt.xlabel(r'Number of bits',fontsize=17);plt.ylabel(r'$f-f^*$',fontsize=16);
plt.legend(fontsize=15);plt.ylim(10**(-6),10**1);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=18)
#ax.set(ylabel=r'$\mathcal{L}-\mathcal{L}^*$') #||\nabla\mathcal{L}(\theta^k)||
#ax.yaxis.label.set_size(15)
plt.savefig('figures/lossbit.eps');plt.savefig('figures/lossbit.pdf')
plt.show();
'''




# Restore the model's state
#E_model.load_weights('my_model.h5')

#E_model.trainable_variabels=mnist_model.trainable_variables
#E_model.non_trainable_variables=mnist_model.non_trainable_variables

#E_model.set_weights(mnist_model.get_weights())
#a=E_model.evaluate(mnist_ta,mnist_tb)




#a=E_model.evaluate(mnist_ta,mnistl)


#cf=np.array([1486.18,1497.47,271.02,406.90,361.90,326.22,282.77,271.56,1525.71,276.77])



plt.figure();plt.plot(deLoss[0],'r',lw=2.5,label='LAQ');plt.plot(deLoss[4],'g',lw=2.5,linestyle='--',label='TWICE');
plt.plot(deLoss[1],'b',lw=3.5,label='GD');
plt.plot(deLoss[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(deLoss[3],'m',lw=2.5,label='LAG');plt.yscale('log');
plt.xlabel(r'Number of iterations',fontsize=17);plt.ylabel('Loss residual~'+r'$(f-f^*)$',fontsize=17);
plt.grid(True, which="both",ls=':')
plt.legend(fontsize=16);plt.ylim(10**(-6),10**1);plt.xlim(-100,3000);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/lossiter.eps');plt.savefig('figures2/lossiter.pdf');
plt.show();



plt.figure();plt.plot(Cr[0],deLoss[0],'r',lw=2.5,label='LAQ');plt.plot(Cr[4],deLoss[4],'g',lw=2.5,linestyle='--',label='TWICE');
plt.plot(Cr[1],deLoss[1],'b',lw=3.5,label='GD');
plt.plot(Cr[2],deLoss[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(Cr[3],deLoss[3],'m',lw=2.5,label='LAG');plt.yscale('log');plt.xscale('log')
plt.xlabel(r'Number of communications',fontsize=17);plt.ylabel('Loss residual~'+r'$(f-f^*)$',fontsize=17);
plt.grid(True, which='both',ls=':')
plt.legend(fontsize=16);plt.ylim(10**(-6),10**1);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/losscom.eps');plt.savefig('figures2/losscom.pdf')
plt.show();



X1=np.zeros(Iter+1);X1[0]=Bit[4,1];X1[1:Iter+1]=Bit[1];
Y1=np.zeros(Iter+1);Y1[0]=deLoss[1,0];Y1[1:Iter+1]=deLoss[1];

X3=np.zeros(Iter+1);X3[0]=Bit[4,1];X3[1:Iter+1]=Bit[3];
Y3=np.zeros(Iter+1);Y3[0]=deLoss[1,0];Y3[1:Iter+1]=deLoss[3];

plt.figure();fig,ax=plt.subplots();plt.rc('text', usetex=True)
plt.plot(Bit[0],deLoss[0],'r',lw=2.5,label='LAQ');plt.plot(Bit[4],deLoss[4],'g',linestyle='--',lw=2.5,label='TWICE');
plt.plot(X1,Y1,'b',lw=3.5,label='GD');
plt.plot(Bit[2],deLoss[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(X3,Y3,'m',lw=2.5,label='LAG');plt.yscale('log');plt.xscale('log')
plt.grid(True, which='both',ls=':')
plt.xlabel(r'Number of bits',fontsize=17);plt.ylabel('Loss residual~'+r'$(f-f^*)$',fontsize=17);
plt.legend(fontsize=16);plt.ylim(10**(-6),10**1);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
#ax.set(ylabel=r'$\mathcal{L}-\mathcal{L}^*$') #||\nabla\mathcal{L}(\theta^k)||
#ax.yaxis.label.set_size(15)
plt.savefig('figures2/lossbit.eps');plt.savefig('figures2/lossbit.pdf')
plt.show();


'''
plt.figure();fig,ax=plt.subplots();plt.rc('text', usetex=True)
plt.plot(b*nv*Cr[0],deLoss[0],'r',lw=2.5,label='QCGD');plt.plot(float*nv*Cr[1],deLoss[1],'b',lw=3.5,label='GD');
plt.plot(b*nv*Cr[2],deLoss[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(float*nv*Cr[3],deLoss[3],'m',lw=2.5,label='LAG');plt.yscale('log');plt.xscale('log')
plt.grid(True, which='both',ls=':')
plt.xlabel(r'Number of bits',fontsize=17);plt.ylabel(r'$f-f^*$',fontsize=13.5);
plt.legend(fontsize=16);plt.ylim(10**(-6),10**1);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
#ax.set(ylabel=r'$\mathcal{L}-\mathcal{L}^*$') #||\nabla\mathcal{L}(\theta^k)||
#ax.yaxis.label.set_size(15)
plt.savefig('figures2/lossbit.eps');plt.savefig('figures2/lossbit.pdf')
plt.show();
'''

plt.figure();fig,ax=plt.subplots();plt.plot(Gradnorm[0],'r',lw=2.5,label='LAQ');plt.plot(Gradnorm[4],'g',lw=2.5,linestyle='--',label='TWO-LAQ');
plt.plot(Gradnorm[1],'b',lw=3.5,label='GD');
plt.plot(Gradnorm[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(Gradnorm[3],'m',lw=2.5,label='LAG');plt.yscale('log');#plt.xscale('log');
plt.grid(True, which='both',ls=':')
plt.xlabel('Number of iterations',fontsize=16);plt.ylabel('Gradient norm~'+r'$||\nabla f||$',fontsize=17);
plt.legend(fontsize=16);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/normiter.eps');plt.savefig('figures2/normiter.pdf')
plt.show();

plt.figure();fig,ax=plt.subplots();plt.plot(Cr[0],Gradnorm[0],'r',lw=2.5,label='LAQ');
plt.plot(Cr[4],Gradnorm[4],'g',lw=2.5,linestyle='--',label='TWO-LAQ');
plt.plot(Cr[1],Gradnorm[1],'b',lw=3.5,label='GD');
plt.plot(Cr[2],Gradnorm[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(Cr[3],Gradnorm[3],'m',lw=2.5,label='LAG');plt.yscale('log');#plt.xscale('log');
plt.grid(True, which='both',ls=':')
plt.xlabel('Number of communications',fontsize=16);plt.ylabel('Gradient norm~'+r'$||\nabla f||$',fontsize=17);
plt.legend(fontsize=16);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/normcom.eps');plt.savefig('figures2/normcom.pdf')
plt.show();

plt.figure();fig,ax=plt.subplots();plt.plot(Bit[0],Gradnorm[0],'r',lw=2.5,label='LAQ');
plt.plot(Bit[4],Gradnorm[4],'g',lw=2.5,linestyle='--',label='TWO-LAQ');
plt.plot(Bit[1],Gradnorm[1],'b',lw=3.5,label='GD');
plt.plot(Bit[2],Gradnorm[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(float*nv*Cr[3],Gradnorm[3],'m',lw=2.5,label='LAG');plt.yscale('log');#plt.xscale('log');
plt.grid(True, which='both',ls=':')
plt.xlabel('Number of bits',fontsize=16);plt.ylabel('Gradient norm~'+r'$||\nabla f||$',fontsize=17);
plt.legend(fontsize=16);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/normbit.eps');plt.savefig('figures2/normbit.pdf')
plt.show();