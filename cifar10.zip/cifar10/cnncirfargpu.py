import tensorflow as tf
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, Activation, Flatten, Conv2D, MaxPooling2D
from tensorflow.compat.v1.keras.layers import BatchNormalization
from tensorflow.keras import regularizers
import time
tic=time.time()

mnist = tf.keras.datasets.cifar10

(x_train, y_train),(x_test, y_test) = mnist.load_data()
#x_train, x_test = x_train / 255.0, x_test / 255.0
mean = np.mean(x_train, axis=(0, 1, 2, 3))
std = np.std(x_train, axis=(0, 1, 2, 3))
x_train = (x_train - mean) / (std + 1e-7)
x_test = (x_test - mean) / (std + 1e-7)

model = Sequential()




tf.compat.v1.random.set_random_seed(20)
'''

model = tf.keras.models.Sequential()
model.add(Conv2D(48, (3, 3), padding='same', activation='relu', input_shape=(32, 32, 3)))
#model.add(BatchNormalization())

model.add(Conv2D(48, (3, 3), padding='same', activation='relu', input_shape=(32, 32, 3)))
#model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2), strides=None, padding='valid', data_format=None))
model.add(Dropout(0.25))

model.add(Conv2D(96, (3, 3), padding='same', activation='relu', input_shape=(32, 32, 3)))
#model.add(BatchNormalization())
model.add(Conv2D(96, (3, 3), padding='same', activation='relu', input_shape=(32, 32, 3)))
#model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2), strides=None, padding='valid', data_format=None))
model.add(Dropout(0.25))

model.add(Conv2D(192, (3, 3), padding='same', activation='relu', input_shape=(32, 32, 3)))
#model.add(BatchNormalization())
model.add(Conv2D(192, (3, 3), padding='same', activation='relu', input_shape=(32, 32, 3)))
#model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2), strides=None, padding='valid', data_format=None))
model.add(Dropout(0.25))

model.add(Flatten())
model.add(Dense(512, input_shape=(256,)))
model.add(BatchNormalization())
model.add(Flatten())
model.add(Dense(256, input_shape=(256,)))
model.add(BatchNormalization())
model.add(Dense(10))
# mnist_model.add(LeakyReLu(0.1))
model.add(Activation('softmax'))
'''


weight_decay = 1e-4
model.add(
    Conv2D(32, (3, 3), padding='same', kernel_regularizer=regularizers.l2(weight_decay), input_shape=x_train.shape[1:]))
model.add(Activation('elu'))
model.add(BatchNormalization())
model.add(Conv2D(32, (3, 3), padding='same', kernel_regularizer=regularizers.l2(weight_decay)))
model.add(Activation('elu'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.2))

model.add(Conv2D(64, (3, 3), padding='same', kernel_regularizer=regularizers.l2(weight_decay)))
model.add(Activation('elu'))
model.add(BatchNormalization())
model.add(Conv2D(64, (3, 3), padding='same', kernel_regularizer=regularizers.l2(weight_decay)))
model.add(Activation('elu'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.3))

model.add(Conv2D(128, (3, 3), padding='same', kernel_regularizer=regularizers.l2(weight_decay)))
model.add(Activation('elu'))
model.add(BatchNormalization())
model.add(Conv2D(128, (3, 3), padding='same', kernel_regularizer=regularizers.l2(weight_decay)))
model.add(Activation('elu'))
model.add(BatchNormalization())
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.4))

'''
model.add(Flatten())
model.add(Dense(256, activation='relu'))
model.add(BatchNormalization())

'''




model.add(Flatten())
model.add(Dense(10, activation='softmax'))





opt_rms = tf.compat.v1.train.RMSPropOptimizer(0.001,decay=1e-6)
model.compile(#optimizer=opt_rms,
    optimizer='adam',
#optimizer=tf.compat.v1.train.GradientDescentOptimizer(0.010),
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

model.fit(x_train, y_train, epochs=20)
y=model.evaluate(x_test, y_test)
toc=time.time()
runtime=toc-tic

#model.save('model/cnncifargpu')