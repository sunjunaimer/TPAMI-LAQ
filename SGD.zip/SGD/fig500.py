'''
data2000 = np.concatenate((deLoss, Gradnorm, Cr,Bit,Acc,Loss), axis=0)
np.savetxt('data2000.txt', data2000)
data2000=np.loadtxt('data2000.txt')
deLoss=data2000[0:nalg,:]
Gradnorm=data2000[nalg:2*nalg,:]
Cr=data2000[2*nalg:3*nalg,:]
Bit=data2000[3*nalg:4*nalg,:]
Acc=data2000[4*nalg:5*nalg,:]
Loss=data2000[5*nalg:6*nalg,:]
'''

trun=1000
Acca=Acc[:,0:trun]
Bita=Bit[:,0:trun]
Gradnorma=Gradnorm[:,0:trun]
Cra=Cr[:,0:trun]
deLossa=deLoss[:,0:trun]
Lossa=Loss[:,0:trun]


plt.figure();plt.plot(deLossa[0],'r',lw=2.5,label='LAQ');plt.plot(deLossa[4],'g',lw=2.5,linestyle='--',label='TWO-LAQ');
plt.plot(deLossa[1],'b',lw=3.5,label='GD');
plt.plot(deLossa[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(deLossa[3],'m',lw=2.5,label='LAG');plt.yscale('log');
plt.xlabel(r'Number of iterations',fontsize=17);plt.ylabel('Loss residual~'+r'$(f-f^*)$',fontsize=17);
plt.grid(True, which="both",ls=':')
plt.legend(fontsize=16);plt.ylim(10**(-2),10**0);plt.xlim(-100,trun);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/lossiter.eps');plt.savefig('figures2/lossiter.pdf');
plt.show();



plt.figure();plt.plot(Cra[0],deLossa[0],'r',lw=2.5,label='LAQ');plt.plot(Cra[4],deLossa[4],'g',lw=2.5,linestyle='--',label='TWO-LAQ');
plt.plot(Cra[1],deLossa[1],'b',lw=3.5,label='GD');
plt.plot(Cra[2],deLossa[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(Cra[3],deLossa[3],'m',lw=2.5,label='LAG');plt.yscale('log');#plt.xscale('log')
plt.xlabel(r'Number of communications',fontsize=17);plt.ylabel('Loss residual~'+r'$(f-f^*)$',fontsize=17);
plt.grid(True, which='both',ls=':')
plt.legend(fontsize=16);plt.ylim(10**(-2),10**0);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/losscom.eps');plt.savefig('figures2/losscom.pdf')
plt.show();



X1=np.zeros(trun+1);X1[0]=Bita[4,1];X1[1:trun+1]=Bita[1];
Y1=np.zeros(trun+1);Y1[0]=deLossa[1,0];Y1[1:trun+1]=deLossa[1];

X3=np.zeros(trun+1);X3[0]=Bita[4,1];X3[1:trun+1]=Bita[3];
Y3=np.zeros(trun+1);Y3[0]=deLossa[1,0];Y3[1:trun+1]=deLossa[3];

plt.figure();fig,ax=plt.subplots();plt.rc('text', usetex=True)
plt.plot(Bita[0],deLossa[0],'r',lw=2.5,label='LAQ');plt.plot(Bita[4],deLossa[4],'g',linestyle='--',lw=2.5,label='TWO-LAQ');
plt.plot(X1,Y1,'b',lw=3.5,label='GD');
plt.plot(Bita[2],deLossa[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(X3,Y3,'m',lw=2.5,label='LAG');plt.yscale('log');#plt.xscale('log')
plt.grid(True, which='both',ls=':')
plt.xlabel(r'Number of bits',fontsize=17);plt.ylabel('Loss residual~'+r'$(f-f^*)$',fontsize=17);
plt.legend(fontsize=16);plt.ylim(10**(-2),10**0);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
#ax.set(ylabel=r'$\mathcal{L}-\mathcal{L}^*$') #||\nabla\mathcal{L}(\theta^k)||
#ax.yaxis.label.set_size(15)
plt.savefig('figures2/lossbit.eps');plt.savefig('figures2/lossbit.pdf')
plt.show();


'''
plt.figure();fig,ax=plt.subplots();plt.rc('text', usetex=True)
plt.plot(b*nv*Cra[0],deLossa[0],'r',lw=2.5,label='QCGD');plt.plot(float*nv*Cra[1],deLossa[1],'b',lw=3.5,label='GD');
plt.plot(b*nv*Cra[2],deLossa[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(float*nv*Cra[3],deLossa[3],'m',lw=2.5,label='LAG');plt.yscale('log');plt.xscale('log')
plt.grid(True, which='both',ls=':')
plt.xlabel(r'Number of bits',fontsize=17);plt.ylabel(r'$f-f^*$',fontsize=13.5);
plt.legend(fontsize=16);plt.ylim(10**(-6),10**1);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
#ax.set(ylabel=r'$\mathcal{L}-\mathcal{L}^*$') #||\nabla\mathcal{L}(\theta^k)||
#ax.yaxis.label.set_size(15)
plt.savefig('figures2/lossbit.eps');plt.savefig('figures2/lossbit.pdf')
plt.show();
'''

plt.figure();fig,ax=plt.subplots();plt.plot(Gradnorma[0],'r',lw=2.5,label='LAQ');plt.plot(Gradnorma[4],'g',lw=2.5,linestyle='--',label='TWO-LAQ');
plt.plot(Gradnorma[1],'b',lw=3.5,label='GD');
plt.plot(Gradnorma[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(Gradnorma[3],'m',lw=2.5,label='LAG');plt.yscale('log');#plt.xscale('log');
plt.grid(True, which='both',ls=':')
plt.xlabel('Number of iterations',fontsize=16);plt.ylabel('Gradient norm~'+r'$||\nabla f||$',fontsize=17);
plt.legend(fontsize=16);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/normiter.eps');plt.savefig('figures2/normiter.pdf')
plt.show();

plt.figure();fig,ax=plt.subplots();plt.plot(Cra[0],Gradnorma[0],'r',lw=2.5,label='LAQ');
plt.plot(Cra[4],Gradnorma[4],'g',lw=2.5,linestyle='--',label='TWO-LAQ');
plt.plot(Cra[1],Gradnorma[1],'b',lw=3.5,label='GD');
plt.plot(Cra[2],Gradnorma[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(Cra[3],Gradnorma[3],'m',lw=2.5,label='LAG');plt.yscale('log');#plt.xscale('log');
plt.grid(True, which='both',ls=':')
plt.xlabel('Number of communications',fontsize=16);plt.ylabel('Gradient norm~'+r'$||\nabla f||$',fontsize=17);
plt.legend(fontsize=16);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/normcom.eps');plt.savefig('figures2/normcom.pdf')
plt.show();

plt.figure();fig,ax=plt.subplots();plt.plot(Bita[0],Gradnorma[0],'r',lw=2.5,label='LAQ');
plt.plot(Bita[4],Gradnorma[4],'g',lw=2.5,linestyle='--',label='TWO-LAQ');
plt.plot(Bita[1],Gradnorma[1],'b',lw=3.5,label='GD');
plt.plot(Bita[2],Gradnorma[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(Bita[3],Gradnorma[3],'m',lw=2.5,label='LAG');plt.yscale('log');#plt.xscale('log');
plt.grid(True, which='both',ls=':')
plt.xlabel('Number of bits',fontsize=16);plt.ylabel('Gradient norm~'+r'$||\nabla f||$',fontsize=17);
plt.legend(fontsize=16);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/normbit.eps');plt.savefig('figures2/normbit.pdf')
plt.show();





plt.figure();plt.plot(Loss[0]);plt.show()
plt.figure();plt.plot(Gradnorma[0]);plt.show()
plt.figure();plt.plot(Acca[0]);plt.show()



plt.figure();fig,ax=plt.subplots();plt.plot(Bita[0],Acca[0],'r',lw=2.5,label='LAQ');
plt.plot(Bita[4],Acca[4],'g',lw=2.5,linestyle='--',label='TWO-LAQ');
plt.plot(Bita[1],Acca[1],'b',lw=3.5,label='GD');
plt.plot(Bita[2],Acca[2],'orange',linestyle='--',lw=2.5,label='QGD');plt.plot(Bita[3],Acca[3],'m',lw=2.5,label='LAG');#plt.yscale('log');#plt.xscale('log');
plt.grid(True, which='both',ls=':')
plt.xlabel('Number of bits',fontsize=16);plt.ylabel('Gradient norm~'+r'$||\nabla f||$',fontsize=17);
plt.legend(fontsize=16);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/normbit.eps');plt.savefig('figures2/normbit.pdf')
plt.show();





plt.figure();fig,ax=plt.subplots();

plt.plot(Bita[1],Acca[1],'b',lw=3.5,label='GD');
plt.plot(Bita[3],Acca[3],'m',lw=2.5,label='LAG')
plt.plot(Bita[2],Acca[2],'orange',linestyle='--',lw=2.5,label='QGD');
plt.plot(Bita[0],Acca[0],'r',lw=2.5,label='LAQ');
plt.plot(Bita[4],Acca[4],'g',lw=2.5,linestyle='--',label='TWO-LAQ');

#plt.yscale('log');#plt.xscale('log');
plt.grid(True, which='both',ls=':')
plt.xlabel('Number of bits',fontsize=16);plt.ylabel('Accuracy',fontsize=17);
plt.legend(fontsize=16);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/acc.eps');plt.savefig('figures2/acc.pdf')
plt.show();





data1=np.loadtxt('datagdDNN.txt')
data2=np.loadtxt('datasite.txt')
data3=np.loadtxt('dataDGC2.txt')

deLoss1=data1[0:nalg,:]
Gradnorm1=data1[nalg:2*nalg,:]
Cr1=data1[2*nalg:3*nalg,:]
Bit1=data1[3*nalg:4*nalg,:]
Loss1=data1[4*nalg:5*nalg,:]

deLoss2=data2[0:nalg,:]
Gradnorm2=data2[nalg:2*nalg,:]
Cr2=data2[2*nalg:3*nalg,:]
Bit2=data2[3*nalg:4*nalg,:]
Loss2=data2[4*nalg:5*nalg,:]

nalg=7

deLoss3=data3[0:nalg,:]
Gradnorm3=data3[nalg:2*nalg,:]
Cr3=data3[2*nalg:3*nalg,:]
Bit3=data3[3*nalg:4*nalg,:]
Loss3=data3[4*nalg:5*nalg,:]


plt.figure();plt.plot(Loss1[1],'b',lw=2.5,label='SGD');
plt.plot(Loss1[2],'orange',linestyle='--',lw=2.5,label='QSGD');
plt.plot(Loss1[3],'g',linestyle=':',lw=2.5,label='SSGD');
plt.plot(Loss3[6],'tan',linestyle='-.',lw=2.5,label='DGC');
plt.plot(Loss2[4],'darkcyan',linestyle='-.',lw=2.5,label='sign-SGD');
plt.plot(Loss2[5],'mediumorchid',linestyle=':',lw=2.5,label='tern-Grad');
plt.plot(Loss[0],'r',lw=2.5,label='SLAQ');
plt.xlabel(r'Number of iterations',fontsize=17);plt.ylabel('Loss~' +r'($f$)',fontsize=17);
plt.grid(True, which="both",ls=':')
plt.legend(fontsize=16);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/sgdlossiter.eps');plt.savefig('figures2/sgdlossiter.pdf');
plt.show();

plt.figure();plt.plot(Cr1[1],Loss1[1],'b',lw=2.5,label='SGD');
plt.plot(Cr1[2],Loss1[2],'orange',linestyle='--',lw=2.5,label='QSGD');
plt.plot(Cr1[3],Loss1[3],'g',linestyle=':',lw=2.5,label='SSGD');#plt.yscale('log');#plt.xscale('log')
plt.plot(Cr3[6],Loss3[6],'tan',linestyle='-.',lw=2.5,label='DGC');
plt.plot(Cr2[4],Loss2[4],'darkcyan',linestyle='-.',lw=2.5,label='sign-SGD');
plt.plot(Cr2[5],Loss2[5],'mediumorchid',linestyle=':',lw=2.5,label='tern-Grad');
plt.plot(Cr[0],Loss[0],'r',lw=2.5,label='SLAQ');
plt.xlabel(r'Number of communications',fontsize=17);plt.ylabel('Loss~' +r'($f$)',fontsize=17);
plt.grid(True, which='both',ls=':')
plt.legend(fontsize=16);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
plt.savefig('figures2/sgdlosscom.eps');plt.savefig('figures2/sgdlosscom.pdf')
plt.show();


plt.figure();fig,ax=plt.subplots();plt.rc('text', usetex=True)
plt.plot(Bit1[1],Loss1[1],'b',lw=2.5,label='SGD');
plt.plot(Bit1[2],Loss1[2],'orange',linestyle='--',lw=2.5,label='QSGD');
plt.plot(Bit1[3],Loss1[3],'g',linestyle=':',lw=2.5,label='SSGD');
plt.plot(Bit3[6],Loss3[6],'tan',linestyle='-.',lw=2.5,label='DGC');
plt.plot(Bit2[4],Loss2[4],'darkcyan',linestyle='-.',lw=2.5,label='sign-SGD');
plt.plot(Bit2[5],Loss2[5],'mediumorchid',linestyle=':',lw=2.5,label='tern-Grad');
plt.plot(Bit[0],Loss[0],'r',lw=2.5,label='SLAQ');
#plt.yscale('log');#plt.xscale('log')
plt.grid(True, which='both',ls=':')
plt.xlabel(r'Number of bits',fontsize=17);plt.ylabel('Loss~' +r'($f$)',fontsize=17);
plt.legend(fontsize=16);
plt.rc('xtick',labelsize=18);plt.rc('ytick',labelsize=17)
#ax.set(ylabel=r'$\mathcal{L}-\mathcal{L}^*$') #||\nabla\mathcal{L}(\theta^k)||
#ax.yaxis.label.set_size(15)
plt.savefig('figures2/sgdlossbit.eps');plt.savefig('figures2/sgdlossbit.pdf')
plt.show();